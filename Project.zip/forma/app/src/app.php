<?php
if(isset($_POST['submit'])) {
$name = trim($_POST ['name']);
$email = trim($_POST ['email']);
$message = trim($_POST ['message']);

if(!empty($name) && !empty($email) && ($message)) {
    if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
include('db.php');

$from = "$email";
$to = "m.sereicikaite@gmail.com";
$subject = "New message";
$autorius = 'From' . $name . ', ' . $email;
$message = htmlspecialchars($message);
//mail($to, $subject, $message, $from);
//echo "<script>alert('Thank you! Your message has been sent');</script>";
}
}
}