<div class="container">
<div class="section-heading">
<a href="logo"><img src="../app/images/logo_02.png" alt="logo"></a>
<p>Stay on the saddle!</p>
</div>