<div class="section-content">
<form class="contact-form" id="contact" action="" method="post">
<div class="input-row">
<input type="text" name="name" placeholder="Your Name" required autofocus>
<input type="email" name="email" placeholder="Your email" required>
</div>
<textarea name="message" rows="6" placeholder="Your Message" required></textarea>
<input type="submit" class="btn btn-form" name="submit">
</form>
</div>
</div>

