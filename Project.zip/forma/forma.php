<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="form.css">
</head>
<body>
<section class="contact">
<div class="container">
<div class="section-heading">
<a href="logo"><img src="./app/images/logo_02.png"></a>
<p>Stay on the saddle!</p>
</div>
<div class="section-content">
<form class="contact-form" id="contact" action="" method="post">
<div class="input-row">
<input type="text" name="name" placeholder="Your Name" required autofocus>
<input type="email" name="email" placeholder="Your email" required>
</div>
<textarea name="message" rows="6" placeholder="Your Message" required></textarea>
<input type="submit" class="btn btn-form" name="submit">
</form>
</div>
</div>

</section>
</body>
</html>



