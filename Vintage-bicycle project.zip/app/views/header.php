<div class="site">
  <header class="site-header">
    <nav class="main-nav">
      <a href="#aboutus" class="main-nav__item">About us</a>
      <a href="#work" class="main-nav__item">Work</a>
      <a href="#" class="main-nav__item"><img src="../app/images/logo_02.png" class="main-nav__logo" alt="AOD logo"></a>
      <a href="#shop" class="main-nav__item">Shop</a>
      <a href="#contact" class="main-nav__item">Contact</a>
    </nav>
    <!--mobile navigation-->
    <nav class=mobile-nav>
    <div class="logo"><img src="../app/images/logo_02.png" alt="logo"></div>
   
      <ul id="mMenu" class="flex-container">
        <li><a href="#aboutus">About us</a></li>
        <li><a href="#work">Work</a></li>
        <li><a href="#shop">Shop</a></li>
        <li><a href="#contact">Contact</a></li>
      </ul>
      <a href="javascript:void(0);" class="icon" onclick="myFunction()">
      <i class="fa fa-bars"></i>
    </a>
    </nav>
    </header>

