<!--About us section-->
<section id="aboutus" class="text-center">
  <img src="../app/images/icon7999_03.png" alt="icon1">
  <h2 class="title">A NEW GENERATION OF VINTAGE BIKE</h2><br>
  <p class="intro">For us, a vintage bike is an old bike made ​​before 1980. Be careful, not to get lost in all the names, some call them old bicycle, retro bicycle or classic bicycle, but our passion for these old bikes is the same. Our old bicycles are mainly European and we offer brands you probably know : pedaling a bike Peugeot, Gitane or Campagnolo is still more fun than sit on a bike saddle plastic made ​​in China, is right ?<br>
    At home, we love the vintage charm of the after war bikes, and even more old, because the vintage bicycle is like good wine, more it ages the more it is good. What a pleasure to see these bikes collections remind us with nostalgia, the great figures of the Tour de France. Besides, if you want to go back in time with us, join us at the Anjou Velo Vintage in France, in June. It is the biggest meeting of old bike, the kingdom of the bicycle classic, or all the fans that we are, come together to discuss old bicycle or find a fork, a frame set, an accessory : the unobtainable bike part.
  </p>

</section>

<!--Work section-->
<section id="work">

  <div class="wrapper">
  <div class="item1"><img src="../app/images/YEBO_Bicycle_Theme_06.png" alt="bicycle"></div>
  <div class="item2"><img src="../app/images/YEBO_Bicycle_Theme_031.jpg" alt="bicycle">
    <img src="../app/images/YEBO_Bicycle_Theme_03.png" alt="icon03">
    <h2 class="title">VINTAGE OLIVA</h2><br>
    <p class="text">Truly a melting pot of cultures and approaches to cycling, North American bicycle
    culture
    has had strong influences from other countries as well as innovative approaches by builders. The
    craft
    continues to evolve today as can be seen in the many current "Keepers of the Flame" craftsmen.</p>
  </div>

  </div>

  <div class="wrapper-two">
		<div class="item3">
			<img src="../app/images/YEBO_Bicycle_Theme99_02.jpg" alt="bicycle">
		  <img src="../app/images/icon255_03.png" alt="icon04" class="icon04">
		  <h2 class="title">LA BORIOSA</h2><br>
		  <p class="text">The La Boriosa represents the latest development of the Alan aluminum alloy frame from
			Italy. This frame utilizes a unique patented construction system of threaded tubing and lugs joined
			with
			epoxy adhesive. Thus it is not brazed or welded.</p>
		  </div>
		<div class="item4">
			<img src="../app/images/YEBO_Bicycle_Theme_035_03.jpg" alt="bicycle">
			
		</div>
	  </div>

  <div class="wrapper-three">
		<div class="item5"><img src="../app/images/YEBO_Bicycle_Theme77_03.jpg" alt="bicycle"></div>
		<div class="item6">
			<img src="../app/images/YEBO_Bicycle_Theme11_03.jpg" alt="bicycle">
		  <img src="../app/images/icon699_03.png" alt="icon05" class="icon05">
		  <h2 class="title">RETRO BIKE</h2><br>
		  <p class="text">This is about more than bikes and cycling. It's about the self-belief that change, movement, and freedom is possible, no matter how tough things can sometimes seem. Our range of vintage bikes and cruisers have been inspired by classic Dutch bike, where modern componentry meets timeless design. </p>
		</div>
		<div class="item7"><img src="../app/images/YEBO_Bicycle_Theme88_02.jpg" alt="bicycle"></div>
	  </div>

</section>
<!--Slideshow section-->
<section id="slideshow">
<div class="slideshow-container">
<div class="mySlides">
  <div class="twitter"><i class="fa fa-twitter fa-2x"></i></div>
  <q>Cycling is a smart decision if you want to keep making smart decisions.</q>
  <p class="author">- Vintage Bikes RI @vintagebike</p>
</div>

<div class="mySlides">
  <div class="twitter"><i class="fa fa-twitter fa-2x"></i></div>
  <q>It's so beautiful in New York now! Why not go for a bike.</q>
  <p class="author">- AOD New York @aod</p>
</div>

<div class="mySlides">
  <div class="twitter"><i class="fa fa-twitter fa-2x"></i></div>
  <q>Premium Cycling is a great source for any vintage bicycle collector, highly recommended.</q>
  <p class="author">- Johan Bruyneel a.k.a ex cyclist and team manager</p>
</div>

<div class="mySlides">
  <div class="twitter"><i class="fa fa-twitter fa-2x"></i></div>
  <q>It was a pleasure to deal with guys and thanks for your professional service.</q>
  <p class="author">- Aleix Espargaro @Moto GP rider</p>
</div>

<div class="mySlides">
  <div class="twitter"><i class="fa fa-twitter fa-2x"></i></div>
  <q>It's so beautiful in New York now! Why not go for a bike.</q>
  <p class="author">- Bike New York @bikenewyork</p>
</div>

<!-- Next/prev buttons -->
<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>

<!-- Dots/bullets/indicators -->
<div class="dot-container">
<span class="dot" onclick="currentSlide(1)"></span>
<span class="dot" onclick="currentSlide(2)"></span>
<span class="dot" onclick="currentSlide(3)"></span>
</div>

</section>

<!--Shop section-->
<section id="shop" class="shop-section">
<div class="shop">
  <figure class="shop__item shop__item--1">
    <img src="../app/images/YEBO_Bicycle_Theme56_02.jpg" class="shop-picture" alt="shop">

</figure>
  <figure class="shop__item shop__item--2">
   <img src="../app/images/YEBO_Bicycle_Theme91_03.jpg" class="shop-picture" alt="shop">
  </figure>
  
  <figure class="shop__item shop__item--3">
   <img src="../app/images/YEBO_Bicycle_Theme02_03.jpg" class="shop-picture" alt="shop">

  </figure>
  <figure class="shop__item shop__item--4">
   <img src="../app/images/YEBO_Bicycle_Theme011_05.jpg" class="shop-picture" alt="shop">
   
  </figure>
  <figure class="shop__item shop__item--5">
    <img src="../app/images/YEBO_Bicycle_Theme477_03.jpg" class="shop-picture" alt="shop">
  
  </figure>
  <figure class="shop__item shop__item--6">
    <img src="../app/images/YEBO_Bicycle_Theme966_02.jpg" class="shop-picture" alt="shop">
   
  </figure>
  <figure class="shop__item shop__item--7">
    <img src="../app/images/YEBO_Bicycle_Theme055_03.jpg" class="shop-picture" alt="shop">

  </figure>
  <figure class="shop__item shop__item--8">
    <img src="../app/images/YEBO_Bicycle_Theme-bag_03.jpg" class="shop-picture" alt="shop">
  </figure>
</div>

<!--shop button-->
<div class="discover-button">
<button class="shop-button">Discover the shop</button>
</div>
</section>

<!--Contact us section-->

<section id="contact" class="contact">
<div class="container">
<div class="section-heading">
<a href="#"><img src="../app/images/logo_02.png" alt="logo"></a>
<p>Stay on the saddle!</p>
</div>
<div class="section-content">
<form class="contact-form" id="contact" action="" method="post">
<div class="input-row">
<input type="text" name="name" placeholder="Your Name" required autofocus>
<input type="email" name="email" placeholder="Your Email" required>
</div>
<textarea name="message" rows="6" placeholder="Your Message" required></textarea>
<input type="submit" class="btn btn-form" value="submit" name="submit">
</form>
</div>
</div>


</section>