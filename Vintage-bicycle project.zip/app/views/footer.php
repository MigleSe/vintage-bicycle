<footer class="footer">
<div class="container">
<div class="row">
  <div class="footer-col">
    
    <ul>
      <li><strong>AOD New York</strong></li>
      <li>2250 Lexington Avenue</li>
      <li>New York, NY 10035</li>
    </ul>
  </div>
  <div class="footer-col">
  
    <div class="social-links">

       <a href="https://www.pinterest.com/" target="_blank"><div class="pinterest"><i class="fab fa-pinterest fa-3x"></i></div></a>
       <a href="https://twitter.com/" target="_blank"><div class="twitter"><i class="fab fa-twitter fa-3x"></i></div></a>
       <a href="https://www.facebook.com/" target="_blank"><div class="facebook"><i class="fab fa-facebook-f fa-3x"></i></div></a>
       

      </div>
  </div>
  <div class="footer-col">
    <img src="../app/images/text-icon-55_03.png" alt="by">
    <img src="../app/images/icon500_03.png" alt="">
  
  </div>
</div>
</div>

<button id="scrollToTopBtn"><i class="fas fa-arrow-up"></i></button>
<div class="footer-bottom">
  <p>Copyright &copy;2021 AOD New York</p>
</div>
</footer>
<script src="../app/js/new.js"></script>