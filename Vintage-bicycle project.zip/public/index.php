<?php 
require __DIR__ . '/../app/src/app.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AOD Vintage Bicycle</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/adaa5eca50.js"></script>
    <link rel="stylesheet" href="../app/css/new.css">
    <link rel="stylesheet" media="screen and (max-width:600px)" href="../app/css/mobile.css">
    <link rel="stylesheet" media="screen and (max-width:980px)" href="../app/css/ipad.css">
    <script>
      function myFunction() {
        var x = document.getElementById("mMenu");
        if (x.style.display === "block") {
          x.style.display = "none";
        } else {
          x.style.display = "block";
        }
      }
    </script>

  </head>
<body>

<?php
include ('../app/views/header.php');
include ('../app/views/content.php');
include ('../app/views/footer.php');
?>
</body>
</html>